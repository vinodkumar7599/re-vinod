import React from 'react';
import './App.css';
import { Nav } from './Components/Nav/nav';
import {Search} from './Components/Search/search';
export default function App() {
  return (
   <div>
    {/* <Search /> */}
 
 
   </div>
  );
}


