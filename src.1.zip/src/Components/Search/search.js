import React from "react";
import './search.css';

export  function Search () {
    return(
        <div className="searchD">
       <p className="searchB"> search </p>
        </div>
    );
}