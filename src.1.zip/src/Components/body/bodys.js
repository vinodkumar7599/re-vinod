import {useState} from "react";
import "./bodys.css";
import { Link, useHistory } from "react-router-dom";
import { Change } from "./Change";

  
export  function Body({movies, setMovies}){
   
  return(
        <div className="box">
        {movies.map((abc , index) => (
           <BodyDiv key={index} id={index} name={abc.names} pic={abc.pic} rate={abc.rating} summary={abc.summary} movies={movies} setMovies={setMovies} />
        ))};
        </div>
      );
};
export  function BodyDiv ({id, name, pic, rate ,summary,movies ,setMovies}){
  const history = useHistory();
  
    return(
        
          <div className="box1">
            <img className="img" alt="name" src={pic}/>
            <h3 className="name">{name}</h3>
            <h5 className="rate">{rate} ⭐ </h5>
            <button onClick={() => (history.push("/Movies/"+ id))} >info</button>
            <button onClick={() => {
              var delet = movies.splice(id,1)
              {console.log(delet)}
              {console.log(movies)}
              setMovies([...movies])}}>delete</button>
              <button
              onClick={()=>( 
              <Change movies={movies} setMovies={setMovies} />
              )}
              >Change</button>
            <p className="summary">{summary}</p>
            
         </div>
        
    );
}
export function AddMovies({movies , setMovies }) {
  
  const [name, setname] = useState()
  const [Pic, setPic] = useState()
  const [rating, setrating] = useState()
  const [summery, setsummery] = useState()
  
 

  const moviesObj = {
      names:name,
      pic:Pic,
      rating:rating,
      summery:summery
  }
  {console.log(movies)}
  return (
      <div className="inputdiv">
          <input className="inputs" onChange={(event)=>{setname(event.target.value)}} placeholder="Enter the name"/><br/>
          <input className="inputs" onChange={(event)=>{setPic(event.target.value)}} placeholder="Enter the Pic"/><br/>
          <input className="inputs" onChange={(event)=>{setrating(event.target.value)}} placeholder="Enter the rating"/><br/>
          <input className="inputs" onChange={(event)=>{setsummery(event.target.value)}} placeholder="Enter the summery"/><br/>
          {/* <input onChange={(event)=>{setname(event.target.value)}} placeholder="Enter the name"/> */}
          <Link to="/Movies"> <button onClick={()=>{setMovies([...movies, moviesObj])}} >Add Movies  </button> </Link>
          
        
      </div>
         );
}
