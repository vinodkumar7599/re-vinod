export function Change({ movies, setMovies }) {
  return (
    <div>
      <input onChange={(event) => {
        setMovies(event.target.value);
{console.log(movies);}
      }}>{movies.name}</input>
      <input onChange={()=>{}}></input>
            <input onChange={()=>{}}></input>
            <input onChange={()=>{}}></input>
            <button>submit</button>
    </div>
  );

}
